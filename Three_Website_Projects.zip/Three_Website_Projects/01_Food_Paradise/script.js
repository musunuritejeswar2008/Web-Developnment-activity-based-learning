let cartCount = 0;
let totalAmount = 0;

function addToCart(price) {
  cartCount++;
  totalAmount += price;
  document.getElementById("cart").textContent = cartCount;
  document.getElementById("total").textContent = totalAmount;
  alert("Item added to your cart!");
}