const travelForm = document.getElementById("travelForm");
const travelDate = document.getElementById("date");
travelDate.min = new Date().toISOString().split("T")[0];

travelForm.addEventListener("submit", function (event) {
  event.preventDefault();
  const name = document.getElementById("name").value.trim();
  const destination = document.getElementById("destination").value;
  const people = document.getElementById("people").value;
  const date = travelDate.value;
  document.getElementById("result").textContent =
    `Thank you, ${name}! Your inquiry for ${destination} (${people} traveler(s)) on ${date} has been received. This is a demo; no booking has been sent.`;
  travelForm.reset();
});