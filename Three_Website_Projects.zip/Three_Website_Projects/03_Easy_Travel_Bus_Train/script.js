let selectedService = null;
let selectedFare = 0;
let passengerCount = 1;
let selectedSeats = [];

const travelDateInput = document.getElementById("date");
travelDateInput.min = new Date().toISOString().split("T")[0];

document.getElementById("searchForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const type = document.getElementById("type").value;
  const source = document.getElementById("source").value.trim();
  const destination = document.getElementById("destination").value.trim();
  passengerCount = Number(document.getElementById("passengers").value);
  if (source.toLowerCase() === destination.toLowerCase()) {
    document.getElementById("searchResult").textContent = "Source and destination must be different.";
    return;
  }
  document.getElementById("searchResult").textContent =
    `Demo search: ${type} services from ${source} to ${destination} on ${travelDateInput.value} for ${passengerCount} passenger(s).`;
  document.querySelectorAll(".service-card").forEach(card => {
    card.style.display = card.dataset.type === type ? "block" : "none";
  });
});

function selectService(name, fare) {
  selectedService = name;
  selectedFare = fare;
  document.querySelectorAll(".service-card").forEach(card => card.style.outline = "none");
  event.currentTarget.closest(".service-card").style.outline = "3px solid #087f8c";
  alert(`${name} selected. Now choose your seats and enter passenger details.`);
}

document.querySelectorAll(".seat").forEach(seat => {
  seat.addEventListener("click", function() {
    const seatNo = this.dataset.seat;
    if (selectedSeats.includes(seatNo)) {
      selectedSeats = selectedSeats.filter(item => item !== seatNo);
      this.classList.remove("selected");
    } else {
      if (selectedSeats.length >= passengerCount) {
        alert(`You can select up to ${passengerCount} seat(s). Search for your passenger count first.`);
        return;
      }
      selectedSeats.push(seatNo);
      this.classList.add("selected");
    }
    document.getElementById("selectedSeats").textContent =
      "Selected Seats: " + (selectedSeats.length ? selectedSeats.join(", ") : "None");
  });
});

document.getElementById("passengerForm").addEventListener("submit", function(event) {
  event.preventDefault();
  if (!selectedService) {
    document.getElementById("bookingResult").textContent = "Please select a bus or train service first.";
    return;
  }
  if (selectedSeats.length === 0) {
    document.getElementById("bookingResult").textContent = "Please select at least one seat.";
    return;
  }
  const name = document.getElementById("passengerName").value.trim();
  const phone = document.getElementById("passengerPhone").value;
  const total = selectedFare * selectedSeats.length;
  document.getElementById("bookingResult").textContent =
    `Demo booking confirmed for ${name}. Service: ${selectedService}. Seats: ${selectedSeats.join(", ")}. Phone: ${phone}. Total fare: ₹${total}. No real ticket has been booked.`;
});