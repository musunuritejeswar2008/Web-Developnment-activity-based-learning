THREE WEB DEVELOPMENT PROJECTS
================================

Included projects:
1. 01_Food_Paradise
   - Online food ordering interface
   - Cart item count and total amount demo

2. 02_Dream_Travels
   - Travel agency website
   - Destination cards, packages, itinerary and inquiry form

3. 03_Easy_Travel_Bus_Train
   - Bus and train booking interface
   - Service search demo, seat selection and fare calculation

HOW TO RUN
----------
1. Extract this ZIP file.
2. Open the required project folder.
3. Open index.html in a web browser, or open the folder in VS Code and use Live Server.
4. Keep index.html, style.css and script.js in the same folder.

NOTE
----
These are front-end student demonstration projects. Forms and booking actions do not
connect to a real server, payment gateway, transport provider or database. Prices,
services and booking confirmations are sample/demo data. Internet access is needed
to load the remote food and destination images.
